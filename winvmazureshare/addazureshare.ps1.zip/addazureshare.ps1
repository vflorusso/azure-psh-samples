﻿

Configuration AddAzureFileShare
{
  param ($MachineName, $AzStorageName, $AzStorageKey, $AzStorageShareName)

  Node $MachineName
  {
	Script AddAzureFileShare { 
		SetScript = { 
            $AzSharePath = "\\" + $AzStorageName + ".file.core.windows.net\" + $AzStorageShareName 
            net use f: $AzSharePath /u:$AzStorageName $AzStorageKey /PERSISTENT:YES
        } 
		TestScript = { 
			Test-Path F:\ 
		} 
		GetScript = { <# This must return a hash table #> }          } 
    }
} 